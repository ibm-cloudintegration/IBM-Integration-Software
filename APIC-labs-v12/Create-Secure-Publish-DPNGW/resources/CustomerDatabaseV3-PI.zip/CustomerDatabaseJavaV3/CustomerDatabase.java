import java.util.ArrayList;
import java.util.List;

import com.ibm.broker.plugin.MbElement;
import com.ibm.broker.plugin.MbException;
import com.ibm.broker.plugin.MbJSON;
import com.ibm.broker.plugin.MbMessage;

public abstract class CustomerDatabase {

	private static List<Customer> customers = new ArrayList<>();

	static {
		customers.add(new Customer("Denis", "Darner", "ddarner@example.com", 
				new Address("1 The Street", "Charlotte", "NC", "US", "00000-0001") ));
							
		customers.add(new Customer("Elana", "Ericson", "eericson@example.com", 
				new Address("2 The Street", "Charlotte", "NC", "US","00000-0001") ));
		
		customers.add(new Customer("Lyle", "Longino", "llongino@example.com", 
				new Address("3 The Street", "Edison", "NJ", "US","08817-0001") ));
		
		customers.add(new Customer("Gerri", "Gaertner", "ggaertner@example.com",
				new Address("4 The Street", "Edison", "NJ", "US","08817-0001") ));
		
		customers.add(new Customer("Willis", "Wicks", "wwicks@example.com",
				new Address("5 The Street", "New Brunswick", "NJ", "US", "08815-0001") ));
				
		customers.add(new Customer("Jessika", "Jeon", "jjeon@example.com",
				new Address("6 The Street", "East Brunswick", "MN", "US", "09817-0001") ));

		customers.add(new Customer("Neil", "Newton", "nnewton@example.com", 
				new Address("7 The Street", "East stroudsberg", "PA", "US","06666-0001") ));

		customers.add(new Customer("Ferne", "Foye", "ffoye@example.com",
				new Address("8 The Street", "Orlando", "FL", "US", "32828-0001") ));

		customers.add(new Customer("Isabella", "Maruyama", "imaruyama@example.com",
				new Address("9 The Street", "Hobfakza", "NE", "US", "22211-0002") ));

		customers.add(new Customer("Sudhakar", "Bodapati", "sbodapati@example.com",
				new Address("10 The Street", "Edison", "NJ", "US", "08817-0001") ));
		
	}

	public static void getAllCustomers(Long max, MbElement[] output) {
		try {
			MbElement root = output[0];
			long counter = 0;
			for (Customer customer : customers) {
				if (max > -1 && counter >= max) {
					break;
				}
				MbElement item = root.createElementAsLastChild(MbJSON.OBJECT, MbJSON.ARRAY_ITEM_NAME, null);
				item.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "id", customer.getID());
				item.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "firstname", customer.getFirstName());
				item.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "lastname", customer.getLastName());
				item.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "email", customer.getEmail());

				// item.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "address", customer.getAddress());
				
				MbElement item2 = item.createElementAsLastChild(MbJSON.OBJECT, "address", null);
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "street", customer.getAddress().getStreet());				
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "city", customer.getAddress().getCity());
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "state", customer.getAddress().getState());
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "country", customer.getAddress().getCountry());
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "postalCode", customer.getAddress().getPostalCode());
				
				
				counter++;
			}
		} catch (MbException e) {
			throw new RuntimeException(e);
		}
	}

	public static MbElement getCustomer(int id) throws MbException {
		for (Customer customer : customers) {
			if (customer.getID() == id) {
				MbMessage message = new MbMessage();
				MbElement result = message.getRootElement().createElementAsLastChild(MbJSON.OBJECT, MbJSON.DATA_ELEMENT_NAME, null);
				result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "id", customer.getID());
				result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "firstname", customer.getFirstName());
				result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "lastname", customer.getLastName());
				result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "email", customer.getEmail());

				// result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "address", customer.getAddress());
				MbElement item2 = result.createElementAsLastChild(MbJSON.OBJECT, "address", null);
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "street", customer.getAddress().getStreet());				
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "city", customer.getAddress().getCity());
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "state", customer.getAddress().getState());
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "country", customer.getAddress().getCountry());
				item2.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "postalCode", customer.getAddress().getPostalCode());
				
				
				return result;
			}
		}
		return null;
	}

	public static boolean deleteCustomer(int id) {
		for (Customer customer : customers) {
			if (customer.getID() == id) {
				customers.remove(customer);
				return true;
			}
		}
		return false;
	}

	public static boolean customerExists(int id) {
		for (Customer customer : customers) {
			if (customer.getID() == id) {
				return true;
			}
		}
		return false;
	}

//	public static MbElement addCustomer(String firstname, String lastname, String email, Address address) throws MbException {

	public static MbElement addCustomer(String firstname, String lastname, String email, MbElement address) throws MbException {
		
		String street = "", city = "", state = "",country = "", postalCode = "";

		try {			
			 street = address.getFirstElementByPath("street").getValueAsString();
			 city = address.getFirstElementByPath("city").getValueAsString();
			 state = address.getFirstElementByPath("state").getValueAsString();
			 country = address.getFirstElementByPath("country").getValueAsString();
			 postalCode = address.getFirstElementByPath("postalCode").getValueAsString();
			
		} catch (MbException e) {
			throw (new RuntimeException(e));
		}
		
		Customer customer = new Customer(firstname, lastname, email, new Address(street, city, state, country, postalCode));
		customers.add(customer);
		MbMessage message = new MbMessage();
		MbElement result = message.getRootElement().createElementAsLastChild(MbJSON.OBJECT, MbJSON.DATA_ELEMENT_NAME, null);
		result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "id", customer.getID());
		result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "message", "A new customer with ID '" + customer.getID() + "' was successfully added to the database.");
		return result;
	}

	public static MbElement updateCustomer(int id, String firstname, String lastname, String email, MbElement address) throws MbException {
		for (Customer customer : customers) {
			if (customer.getID() == id) {
				customer.setFirstName(firstname);
				customer.setLastName(lastname);
				customer.setEmail(email);

				String street = "", city = "", state = "",country = "", postalCode = "";

				if (address != null) 
				{
					street = address.getFirstElementByPath("street").getValueAsString();
					city = address.getFirstElementByPath("city").getValueAsString();
					state = address.getFirstElementByPath("state").getValueAsString();
					country = address.getFirstElementByPath("country").getValueAsString();
					postalCode = address.getFirstElementByPath("postalCode").getValueAsString();				
				}
				customer.setAddress(new Address(street, city, state, country, postalCode));
				
				MbMessage message = new MbMessage();
				MbElement result = message.getRootElement().createElementAsLastChild(MbJSON.OBJECT, MbJSON.DATA_ELEMENT_NAME, null);
				result.createElementAsLastChild(MbElement.TYPE_NAME_VALUE, "message", "An existing customer with ID '" + customer.getID() + "' was successfully updated in the database.");
				return result;
			}
		}
		return null;
	}

}
